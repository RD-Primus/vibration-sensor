var group___s_e_q_u_e_n_c_e_r___exported__macro =
[
    [ "UTIL_SEQ_TaskFunction", "group___s_e_q_u_e_n_c_e_r___exported__macro.html#gac4b0290fac7278810aa24b9be4574da1", null ],
    [ "UTIL_SEQ_TaskParamDef", "group___s_e_q_u_e_n_c_e_r___exported__macro.html#ga99985a546d3297b5fd8ace7f5f045c14", null ]
];